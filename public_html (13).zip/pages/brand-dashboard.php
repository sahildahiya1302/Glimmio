<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Brand Dashboard</title>
    <link rel="stylesheet" href="/../css/brand-dashboard-style.css" />
</head>
<body>
    <div class="dashboard-container">
        <div class="sidebar">
            <h2>Brand Dashboard</h2>
            <section id="profile">
                <img id="profile-pic" src="" alt="Profile Picture" />
                <p id="profile-name">Brand Name</p>
                <p id="profile-email">brand@example.com</p>
            </section>
            <ul>
                <li><a href="#post-campaign" class="active">Post Campaign</a></li>
                <li><a href="#campaign-list">View Campaigns</a></li>
                <li><a href="#request-list">View Requests</a></li>
                <li><a href="#submission-list">Content Submissions</a></li>
            </ul>
        </div>

        <div class="main-content">
            <section id="post-campaign">
                <h3>Post a New Campaign</h3>
                <form id="post-campaign-form" enctype="multipart/form-data">
                    <label for="campaign-image">Campaign Image</label>
                    <input type="file" id="campaign-image" name="image" />
                    <label for="campaign-title">Campaign Title</label>
                    <input type="text" id="campaign-title" name="title" placeholder="Campaign Title" required />
                    <label for="campaign-objective">Objective</label>
                    <input type="text" id="campaign-objective" name="objective" placeholder="Objective" />
                    <label for="campaign-description">Description</label>
                    <textarea id="campaign-description" name="description" placeholder="Campaign Description" required></textarea>
                    <label for="campaign-category">Category</label>
                    <input type="text" id="campaign-category" name="category" placeholder="Category" />

                    <label for="campaign-guidelines">Guidelines</label>
                    <textarea id="campaign-guidelines" name="guidelines" placeholder="Guidelines"></textarea>
                    <label for="campaign-hashtags">Hashtags/Mentions</label>
                    <input type="text" id="campaign-hashtags" name="hashtags_required" placeholder="#brand @mention" />
                    <label for="campaign-captions">Caption Suggestions</label>
                    <textarea id="campaign-captions" name="caption_examples" placeholder="Example captions"></textarea>

                    <label for="campaign-file">Brief Upload</label>
                    <input type="file" id="campaign-file" name="brief_file" />

                    <label for="campaign-min-followers">Min Followers</label>
                    <input type="number" id="campaign-min-followers" name="min_followers" placeholder="0" />
                    <label for="campaign-badge">Badge Requirement</label>
                    <select id="campaign-badge" name="badge_min">
                        <option value="bronze">Bronze</option>
                        <option value="silver">Silver</option>
                        <option value="gold">Gold</option>
                        <option value="elite">Elite</option>
                    </select>
                    <label for="campaign-max-inf">Max Influencers</label>
                    <input type="number" id="campaign-max-inf" name="max_influencers" />

                    <label for="campaign-start">Start Date</label>
                    <input type="date" id="campaign-start" name="start_date" />
                    <label for="campaign-end">End Date</label>
                    <input type="date" id="campaign-end" name="end_date" />
                    <label for="campaign-goal">Goal Type</label>
                    <select id="campaign-goal" name="goal_type">
                        <option value="CPM">CPM</option>
                        <option value="CPE">CPE</option>
                    </select>
                    <label for="campaign-target">Target Metrics</label>
                    <input type="number" id="campaign-target" name="target_metrics" placeholder="10000" />
                    <label for="campaign-rate">Rate</label>
                    <input type="number" id="campaign-rate" name="rate" placeholder="Rate" required />
                    <label for="campaign-budget">Total Budget</label>
                    <input type="number" id="campaign-budget" name="budget_total" placeholder="Budget" required />
                    <label for="campaign-commission">Commission %</label>
                    <input type="number" step="0.01" id="campaign-commission" name="commission_percent" placeholder="10" />
                    <button type="submit" id="post-campaign-btn">Post Campaign</button>
                </form>
            </section>

            <section id="campaign-list">
                <h3>Your Campaigns</h3>
                <ul></ul>
            </section>

            <section id="request-list">
                <h3>Requests</h3>
                <ul></ul>
            </section>

            <section id="submission-list" style="display:none;">
                <h3>Content Submissions</h3>
                <ul></ul>
            </section>
        </div>
    </div>

    <script>
        // Load profile data from backend API
        async function loadProfile() {
            try {
                const response = await fetch('/backend/profile.php');
                const result = await response.json();
                if (result.success) {
                    const profile = result.data;
                    document.getElementById('profile-name').textContent = profile.username || 'Brand Name';
                    document.getElementById('profile-email').textContent = profile.email || 'brand@example.com';
                    document.getElementById('profile-pic').src = profile.profilePic || '';
                } else {
                    console.error('Failed to load profile:', result.message);
                }
            } catch (error) {
                console.error('Error loading profile:', error);
            }
        }

        // Post a new campaign
        document.getElementById('post-campaign-form').addEventListener('submit', async function (e) {
            e.preventDefault();

            const formData = new FormData(this);

            try {
                const response = await fetch('/backend/campaigns.php?action=post_campaign', {
                    method: 'POST',
                    body: formData,
                });
                const result = await response.json();
                alert(result.message);
                if (result.success) {
                    this.reset();
                    loadCampaigns();
                }
            } catch (error) {
                alert('Error posting campaign: ' + error.message);
            }
        });

        // Load campaigns
        async function loadCampaigns() {
            try {
                const response = await fetch('/backend/campaigns.php?action=list_campaigns');
                const result = await response.json();
                const campaignList = document.querySelector('#campaign-list ul');
                campaignList.innerHTML = '';
                if (result.success && result.data.length > 0) {
                    result.data.forEach((campaign) => {
                        const li = document.createElement('li');
                        li.innerHTML = `
                            <div class="campaign-card">
                                ${campaign.image_url ? `<img src="${campaign.image_url}" alt="Campaign Image" />` : ''}
                                <span class="status-dot" style="background-color: ${campaign.status === 'active' ? 'green' : 'red'};"></span>
                                <h3>${campaign.title}</h3>
                                <p>${campaign.description}</p>
                                <p>Category: ${campaign.category || ''}</p>
                                <p>Goal: ${campaign.goal_type} @ ${campaign.rate}</p>
                                <p>Target: ${campaign.target_metrics || ''}</p>
                                <p>Budget: ${campaign.budget_total}</p>
                                <p>Min Followers: ${campaign.min_followers}</p>
                                <p>Badge Requirement: ${campaign.badge_min}</p>
                                <p>Status: ${campaign.status}</p>
                                <button class="view-requests-button" data-id="${campaign.id}">View Accepted Requests</button>
                                <div class="requests-container" id="requests-${campaign.id}" style="display: none;">
                                    <h4>Accepted Requests:</h4>
                                    <div class="requests-list"></div>
                                </div>
                                <button class="end-campaign-button" data-id="${campaign.id}">End Campaign</button>
                            </div>
                        `;
                        campaignList.appendChild(li);
                    });

                    // Attach event listeners to buttons
                    document.querySelectorAll('.view-requests-button').forEach(button => {
                        button.addEventListener('click', () => {
                            const campaignId = button.getAttribute('data-id');
                            toggleRequests(campaignId);
                        });
                    });

                    document.querySelectorAll('.end-campaign-button').forEach(button => {
                        button.addEventListener('click', () => {
                            const campaignId = button.getAttribute('data-id');
                            endCampaign(campaignId);
                        });
                    });
                } else {
                    campaignList.innerHTML = '<p>No campaigns found.</p>';
                }
            } catch (error) {
                console.error('Error loading campaigns:', error);
            }
        }

        // Toggle requests display for a campaign
        async function toggleRequests(campaignId) {
            const container = document.getElementById(`requests-${campaignId}`);
            if (container.style.display === 'block') {
                container.style.display = 'none';
                container.querySelector('.requests-list').innerHTML = '';
            } else {
                container.style.display = 'block';
                await loadRequests(campaignId);
            }
        }

        // Load requests for a campaign
        async function loadRequests(campaignId) {
            try {
                const response = await fetch('/backend/requests.php?action=list_requests');
                const result = await response.json();
                const requestsList = document.querySelector(`#requests-${campaignId} .requests-list`);
                requestsList.innerHTML = '';
                if (result.success && result.data.length > 0) {
                    const filteredRequests = result.data.filter(r => r.campaign_id == campaignId);
                    if (filteredRequests.length === 0) {
                        requestsList.innerHTML = '<p>No requests found.</p>';
                        return;
                    }
                    filteredRequests.forEach(request => {
                        const div = document.createElement('div');
                        div.classList.add('request-item');
                        div.innerHTML = `
                            <p><strong>Influencer:</strong> ${request.influencer_uid}</p>
                            <p>Status: ${request.status}</p>
                            <p>Created At: ${request.created_at}</p>
                            <div class="action-buttons">
                                ${request.status === 'pending' ? `
                                <button class="accept-request-button" data-id="${request.id}" data-influencer="${request.influencer_uid}">Accept</button>
                                <button class="reject-request-button" data-id="${request.id}">Reject</button>
                                ` : ''}
                            </div>
                        `;
                        requestsList.appendChild(div);
                    });

                    // Attach event listeners for accept/reject buttons
                    requestsList.querySelectorAll('.accept-request-button').forEach(button => {
                        button.addEventListener('click', () => {
                            const requestId = button.getAttribute('data-id');
                            const influencerUID = button.getAttribute('data-influencer');
                            updateRequestStatus(requestId, 'accepted');
                        });
                    });
                    requestsList.querySelectorAll('.reject-request-button').forEach(button => {
                        button.addEventListener('click', () => {
                            const requestId = button.getAttribute('data-id');
                            updateRequestStatus(requestId, 'rejected');
                        });
                    });
                } else {
                    requestsList.innerHTML = '<p>No requests found.</p>';
                }
            } catch (error) {
                console.error('Error loading requests:', error);
            }
        }

        // Update request status (accept/reject)
        async function updateRequestStatus(requestId, status) {
            try {
                const formData = new FormData();
                formData.append('request_id', requestId);
                formData.append('status', status);

                const response = await fetch('/backend/requests.php?action=update_request_status', {
                    method: 'POST',
                    body: formData,
                });
                const result = await response.json();
                alert(result.message);
                if (result.success) {
                    loadCampaigns();
                }
            } catch (error) {
                alert('Error updating request status: ' + error.message);
            }
        }

        // End a campaign (update status)
        async function endCampaign(campaignId) {
            try {
                const formData = new FormData();
                formData.append('campaign_id', campaignId);
                formData.append('status', 'ended');

                const response = await fetch('/backend/campaigns.php?action=end_campaign', {
                    method: 'POST',
                    body: formData,
                });
                const result = await response.json();
                alert(result.message);
                if (result.success) {
                    loadCampaigns();
                }
            } catch (error) {
                alert('Error ending campaign: ' + error.message);
            }
        }

        // Load content submissions
        async function loadSubmissions() {
            try {
                const response = await fetch('/backend/submissions.php?action=list');
                const result = await response.json();
                const list = document.querySelector('#submission-list ul');
                list.innerHTML = '';
                if (result.success && result.data.length > 0) {
                    result.data.forEach(sub => {
                        const li = document.createElement('li');
                        li.innerHTML = `
                            <div class="submission-item">
                                <p>Campaign ID: ${sub.campaign_id}</p>
                                <p>Status: ${sub.status}</p>
                                ${sub.media_url ? `<a href="${sub.media_url}" target="_blank">View Media</a>` : ''}
                                ${sub.status === 'pending' || sub.status === 'needs_revision' ? `
                                    <button class="approve-sub" data-id="${sub.id}">Approve</button>
                                    <button class="reject-sub" data-id="${sub.id}">Reject</button>
                                ` : ''}
                            </div>
                        `;
                        list.appendChild(li);
                    });

                    document.querySelectorAll('.approve-sub').forEach(btn => {
                        btn.addEventListener('click', () => updateSubmission(btn.getAttribute('data-id'), 'approved'));
                    });
                    document.querySelectorAll('.reject-sub').forEach(btn => {
                        btn.addEventListener('click', () => updateSubmission(btn.getAttribute('data-id'), 'rejected'));
                    });
                } else {
                    list.innerHTML = '<p>No submissions.</p>';
                }
            } catch (err) {
                console.error('Error loading submissions:', err);
            }
        }

        async function updateSubmission(id, status) {
            const formData = new FormData();
            formData.append('submission_id', id);
            formData.append('status', status);
            const response = await fetch('/backend/submissions.php?action=update', {
                method: 'POST',
                body: formData,
            });
            const result = await response.json();
            alert(result.message);
            if (result.success) {
                loadSubmissions();
            }
        }

        // Initial load
        document.addEventListener('DOMContentLoaded', () => {
            loadProfile();
            loadCampaigns();
            loadSubmissions();

            const links = document.querySelectorAll('.sidebar ul li a');
            const sections = document.querySelectorAll('.main-content section');
            links.forEach(link => {
                link.addEventListener('click', e => {
                    e.preventDefault();
                    const targetID = link.getAttribute('href').substring(1);
                    sections.forEach(sec => sec.style.display = 'none');
                    document.getElementById(targetID).style.display = 'block';
                });
            });
            sections.forEach(sec => sec.style.display = 'none');
            document.getElementById('post-campaign').style.display = 'block';
        });
    </script>
</body>
</html>